﻿using DataFixer.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataFixer
{
    public partial class MainForm : Form
    {
        private List<Employee> employees;

        private List<Employee> searchedList = new List<Employee>();

        private string currentRole = "";

        private int currentList = 0;


        public MainForm()
        {
            InitializeComponent();
            employees = Parser.employees;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            recordsCountLabel.Text = "Total Records: " + employees.Count;
            categoryRecordsCount.Text = "Records: " + employees.Count;
            CategoryComboBox.SelectedIndex = 0;

            foreach (Employee employee in employees)
            {
                employeeList.Items.Add(employee.Role +": "+ employee.FirstName + " " + employee.LastName);
            }
        }

        private void SaveOnFileButton_Click(object sender, EventArgs e)
        {
            List<Employee> employees = new List<Employee>();

            switch (currentList)
            {
                case 1:
                    employees = this.searchedList;
                    break;

                default:
                    employees = this.employees;
                    break;
            }

            Parser.SaveFixedData(employees, currentRole);
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void SelectEmployeeButton_Click(object sender, EventArgs e)
        {
            Employee employee = currentList == 0 ? employees[employeeList.SelectedIndex]  : searchedList[employeeList.SelectedIndex];

            parameter.Text = employee.Parameter;
            id.Text = employee.Id;
            firstName.Text = employee.FirstName;
            lastName.Text = employee.LastName;
            gender.Text = employee.Gender;
            dateOfBirth.Text = employee.DateofBirth;
            role.Text = employee.Role;
        }

        private void SelectCategoryButton_Click(object sender, EventArgs e)
        {
            int currentCategory = CategoryComboBox.SelectedIndex;
            searchedList.Clear();

            switch (currentCategory)
            {
                case 1:
                    currentList = 1;
                    currentRole = "Product Manager";
                    break;

                case 2:
                    currentList = 1;
                    currentRole = "Sale Manager";
                    break;

                case 3:
                    currentList = 1;
                    currentRole = "Senior Developer";
                    break;

                case 4:
                    currentList = 1;
                    currentRole = "Junior Developer";
                    break;

                default:
                    currentList = 0;
                    currentRole = "All Employees";
                    break;
            }

            employeeList.Items.Clear();

            int count = 0;

            if (currentList == 1)
            {
                foreach (Employee employee in employees)
                {
                    if (employee.Role == currentRole)
                    {
                        searchedList.Add(employee);
                        employeeList.Items.Add(employee.Role + ": " + employee.FirstName + " " + employee.LastName);
                        count++;
                    }
                }
            } 
            else
            {
                ResetSearchButton_Click(sender, e);
                return;
            }

            categoryRecordsCount.Text = "Records: " + count;
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            string term = SeachTermTextBox.Text;
            searchedList.Clear();

            List<Employee> temp = new List<Employee>();

            foreach (Employee employee in employees)
            {
                if ((employee.FirstName + " " + employee.LastName).Contains(term))
                {
                    searchedList.Add(employee);
                    temp.Add(employee);
                }
            }

            if (temp.Count > 0)
            {
                currentList = 1;
                employeeList.Items.Clear();

                foreach (Employee employee in temp)
                {
                    employeeList.Items.Add(employee.Role + ": " + employee.FirstName + " " + employee.LastName);
                }

                categoryRecordsCount.Text = "Records: " + temp.Count;
                return;
            }

            MessageBox.Show("No results found !", "Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void ResetSearchButton_Click(object sender, EventArgs e)
        {
            employeeList.Items.Clear();
            currentList = 0;
            currentRole = "All Employees";

            foreach (Employee employee in employees)
            {
               employeeList.Items.Add(employee.Role + ": " + employee.FirstName + " " + employee.LastName);
            }

            categoryRecordsCount.Text = "Records: " + employees.Count;
        }
    }
}
