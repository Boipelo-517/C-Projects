﻿using DataFixer.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataFixer
{
    static class Parser
    {
        public static List<Employee> employees = new List<Employee>();

        public static IDictionary<string,string> CreateSearchTermDictionary(string[] lines)
        {
            IDictionary<string, string> searchForList = new Dictionary<string, string>();

            try
            {

                foreach (string line in lines)
                {
                    if (line.StartsWith("ID")) { continue; }

                    string[] data = line.Split(':');
                    string[] splittedName = data[1].Split(' ');

                    searchForList.Add(splittedName[1].Substring(0, 2) + splittedName[2].Substring(0, 3), data[1]);
                }

                return searchForList;

            } catch {
                
            }

            return null;
        }

        public static void FixFile(string filename)
        {
            string[] brokenFileLines = File.ReadAllLines(filename);
            IDictionary<string,string> searchForList = CreateSearchTermDictionary(brokenFileLines);


            foreach (KeyValuePair<string,string> term in searchForList)
            {
                for (int i = 0; i < brokenFileLines.Length; i++)
                {
                    if (brokenFileLines[i].StartsWith("Name:")) { continue; }

                    if (brokenFileLines[i].Contains("ID: " + term.Key))
                    {
                        string[] splittedParameter = brokenFileLines[i].Split(' ')[1].Split('-');

                        string id = splittedParameter[2] + term.Key.Substring(0,4) + splittedParameter[1];
                        string dateofbirth = splittedParameter[1].Substring(0, 4) + "-" + splittedParameter[1].Substring(4, 2) + "-" + splittedParameter[1].Substring(6, 2);
                        string role = "";


                        switch (splittedParameter[2])
                        {
                            case "SD":
                                role = "Senior Developer";
                                break;

                            case "PM":
                                role = "Product Manager";
                                break;

                            case "JD":
                                role = "Junior Developer";
                                break;

                            case "SM":
                                role = "Sale Manager";
                                break;
                        }

                        string gender = splittedParameter[3] == "F" ? "Female" : "Male";


                        Employee employee = new Employee();
                        employee.Id = id;
                        employee.FirstName = term.Value.Split(' ')[1];
                        employee.LastName = term.Value.Split(' ')[2];
                        employee.Gender = gender;
                        employee.DateofBirth = dateofbirth;
                        employee.Role = role;
                        employee.Parameter = term.Key;

                        employees.Add(employee);

                        break;
                    }
                }
            }

            MainForm mainForm = new MainForm();
            mainForm.ShowDialog();
        }

        public static void SaveFixedData(List<Employee> employees, string role)
        {
            SaveFileDialog savefileDialog = new SaveFileDialog();
            savefileDialog.Filter = "Text File |*.txt";
            savefileDialog.Title= "Save fixed data";
            savefileDialog.ShowDialog();

            List<string> lines = new List<string>();

            if (savefileDialog.FileName != "null")
            {
                lines.Add("+++++++++++++++++++++++ Fixed Data +++++++++++++++++++++++++");
                lines.Add("# Number of Records: "+ employees.Count);
                lines.Add("# Job Role: " + role);
                lines.Add("\n");

                foreach(Employee employee in employees)
                {
                    lines.Add("Parameter: " + employee.Parameter);
                    lines.Add("Id: " + employee.Id);
                    lines.Add("First Name: " + employee.FirstName);
                    lines.Add("Last Name: " + employee.LastName);
                    lines.Add("Gender: " + employee.Gender);
                    lines.Add("Date of Birth: " + employee.DateofBirth);
                    lines.Add("Role: " + employee.Role);
                    lines.Add("--------------------------------------------------");
                }

                File.WriteAllLines(savefileDialog.FileName, lines.ToArray());
                MessageBox.Show("The file was created successfully !", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

    }
}
