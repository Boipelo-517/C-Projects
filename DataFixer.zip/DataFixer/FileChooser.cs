﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataFixer
{
    public partial class FileChooser : Form
    {
        private string filename;

        public FileChooser()
        {
            InitializeComponent();
        }

        private void OKButton_Click(object sender, EventArgs e)
        {
            Parser.FixFile(filename);
            Close();
        }

        private void LoadFileButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog.ShowDialog();
            this.filename = OpenFileDialog.FileName;

            selectedFilePath.Text = this.filename;
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
