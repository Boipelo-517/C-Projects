﻿namespace DataFixer
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.recordsCountLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ResetSearchButton = new System.Windows.Forms.Button();
            this.SearchButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SeachTermTextBox = new System.Windows.Forms.TextBox();
            this.copyright = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.SaveOnFileButton = new System.Windows.Forms.Button();
            this.SelectEmployeeButton = new System.Windows.Forms.Button();
            this.employeeList = new System.Windows.Forms.ListBox();
            this.SelectCategoryButton = new System.Windows.Forms.Button();
            this.CategoryComboBox = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.categoryRecordsCount = new System.Windows.Forms.Label();
            this.role = new System.Windows.Forms.Label();
            this.gender = new System.Windows.Forms.Label();
            this.dateOfBirth = new System.Windows.Forms.Label();
            this.lastName = new System.Windows.Forms.Label();
            this.firstName = new System.Windows.Forms.Label();
            this.id = new System.Windows.Forms.Label();
            this.parameter = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ExitButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Fixed Data";
            // 
            // recordsCountLabel
            // 
            this.recordsCountLabel.AutoSize = true;
            this.recordsCountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.recordsCountLabel.Location = new System.Drawing.Point(645, 18);
            this.recordsCountLabel.Name = "recordsCountLabel";
            this.recordsCountLabel.Size = new System.Drawing.Size(110, 18);
            this.recordsCountLabel.TabIndex = 1;
            this.recordsCountLabel.Text = "Total Records: ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ResetSearchButton);
            this.groupBox1.Controls.Add(this.SearchButton);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.SeachTermTextBox);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 63);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(776, 65);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Search";
            // 
            // ResetSearchButton
            // 
            this.ResetSearchButton.Location = new System.Drawing.Point(705, 23);
            this.ResetSearchButton.Name = "ResetSearchButton";
            this.ResetSearchButton.Size = new System.Drawing.Size(65, 31);
            this.ResetSearchButton.TabIndex = 3;
            this.ResetSearchButton.Text = "Reset";
            this.ResetSearchButton.UseVisualStyleBackColor = true;
            this.ResetSearchButton.Click += new System.EventHandler(this.ResetSearchButton_Click);
            // 
            // SearchButton
            // 
            this.SearchButton.BackColor = System.Drawing.Color.Green;
            this.SearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchButton.ForeColor = System.Drawing.Color.White;
            this.SearchButton.Location = new System.Drawing.Point(589, 23);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(109, 32);
            this.SearchButton.TabIndex = 2;
            this.SearchButton.Text = "Search";
            this.SearchButton.UseVisualStyleBackColor = false;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(15, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name:";
            // 
            // SeachTermTextBox
            // 
            this.SeachTermTextBox.Location = new System.Drawing.Point(76, 29);
            this.SeachTermTextBox.Name = "SeachTermTextBox";
            this.SeachTermTextBox.Size = new System.Drawing.Size(507, 20);
            this.SeachTermTextBox.TabIndex = 0;
            // 
            // copyright
            // 
            this.copyright.AutoSize = true;
            this.copyright.BackColor = System.Drawing.Color.Red;
            this.copyright.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.copyright.ForeColor = System.Drawing.Color.White;
            this.copyright.Location = new System.Drawing.Point(644, 507);
            this.copyright.Name = "copyright";
            this.copyright.Size = new System.Drawing.Size(144, 20);
            this.copyright.TabIndex = 7;
            this.copyright.Text = "FALCONS TEAM";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.SaveOnFileButton);
            this.groupBox2.Controls.Add(this.SelectEmployeeButton);
            this.groupBox2.Controls.Add(this.employeeList);
            this.groupBox2.Controls.Add(this.SelectCategoryButton);
            this.groupBox2.Controls.Add(this.CategoryComboBox);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 145);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(399, 379);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Categories";
            // 
            // SaveOnFileButton
            // 
            this.SaveOnFileButton.Location = new System.Drawing.Point(6, 341);
            this.SaveOnFileButton.Name = "SaveOnFileButton";
            this.SaveOnFileButton.Size = new System.Drawing.Size(386, 23);
            this.SaveOnFileButton.TabIndex = 4;
            this.SaveOnFileButton.Text = "Save To File";
            this.SaveOnFileButton.UseVisualStyleBackColor = true;
            this.SaveOnFileButton.Click += new System.EventHandler(this.SaveOnFileButton_Click);
            // 
            // SelectEmployeeButton
            // 
            this.SelectEmployeeButton.Location = new System.Drawing.Point(6, 312);
            this.SelectEmployeeButton.Name = "SelectEmployeeButton";
            this.SelectEmployeeButton.Size = new System.Drawing.Size(386, 23);
            this.SelectEmployeeButton.TabIndex = 3;
            this.SelectEmployeeButton.Text = "Select Employee";
            this.SelectEmployeeButton.UseVisualStyleBackColor = true;
            this.SelectEmployeeButton.Click += new System.EventHandler(this.SelectEmployeeButton_Click);
            // 
            // employeeList
            // 
            this.employeeList.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeList.FormattingEnabled = true;
            this.employeeList.Location = new System.Drawing.Point(7, 57);
            this.employeeList.Name = "employeeList";
            this.employeeList.Size = new System.Drawing.Size(386, 251);
            this.employeeList.TabIndex = 2;
            // 
            // SelectCategoryButton
            // 
            this.SelectCategoryButton.Location = new System.Drawing.Point(261, 18);
            this.SelectCategoryButton.Name = "SelectCategoryButton";
            this.SelectCategoryButton.Size = new System.Drawing.Size(132, 23);
            this.SelectCategoryButton.TabIndex = 1;
            this.SelectCategoryButton.Text = "Select";
            this.SelectCategoryButton.UseVisualStyleBackColor = true;
            this.SelectCategoryButton.Click += new System.EventHandler(this.SelectCategoryButton_Click);
            // 
            // CategoryComboBox
            // 
            this.CategoryComboBox.FormattingEnabled = true;
            this.CategoryComboBox.Items.AddRange(new object[] {
            "All Employees",
            "Product Manager",
            "Sale Manager",
            "Senior Developer",
            "Junior Developer"});
            this.CategoryComboBox.Location = new System.Drawing.Point(6, 20);
            this.CategoryComboBox.Name = "CategoryComboBox";
            this.CategoryComboBox.Size = new System.Drawing.Size(249, 21);
            this.CategoryComboBox.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.categoryRecordsCount);
            this.groupBox3.Controls.Add(this.role);
            this.groupBox3.Controls.Add(this.gender);
            this.groupBox3.Controls.Add(this.dateOfBirth);
            this.groupBox3.Controls.Add(this.lastName);
            this.groupBox3.Controls.Add(this.firstName);
            this.groupBox3.Controls.Add(this.id);
            this.groupBox3.Controls.Add(this.parameter);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(417, 145);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(371, 350);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Employee Information";
            // 
            // categoryRecordsCount
            // 
            this.categoryRecordsCount.AutoSize = true;
            this.categoryRecordsCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.categoryRecordsCount.Location = new System.Drawing.Point(15, 28);
            this.categoryRecordsCount.Name = "categoryRecordsCount";
            this.categoryRecordsCount.Size = new System.Drawing.Size(74, 16);
            this.categoryRecordsCount.TabIndex = 5;
            this.categoryRecordsCount.Text = "Records: ";
            // 
            // role
            // 
            this.role.AutoSize = true;
            this.role.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.role.Location = new System.Drawing.Point(163, 288);
            this.role.Name = "role";
            this.role.Size = new System.Drawing.Size(38, 20);
            this.role.TabIndex = 13;
            this.role.Text = "N/A";
            // 
            // gender
            // 
            this.gender.AutoSize = true;
            this.gender.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gender.Location = new System.Drawing.Point(163, 251);
            this.gender.Name = "gender";
            this.gender.Size = new System.Drawing.Size(38, 20);
            this.gender.TabIndex = 12;
            this.gender.Text = "N/A";
            // 
            // dateOfBirth
            // 
            this.dateOfBirth.AutoSize = true;
            this.dateOfBirth.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateOfBirth.Location = new System.Drawing.Point(163, 212);
            this.dateOfBirth.Name = "dateOfBirth";
            this.dateOfBirth.Size = new System.Drawing.Size(38, 20);
            this.dateOfBirth.TabIndex = 11;
            this.dateOfBirth.Text = "N/A";
            // 
            // lastName
            // 
            this.lastName.AutoSize = true;
            this.lastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastName.Location = new System.Drawing.Point(163, 178);
            this.lastName.Name = "lastName";
            this.lastName.Size = new System.Drawing.Size(38, 20);
            this.lastName.TabIndex = 10;
            this.lastName.Text = "N/A";
            // 
            // firstName
            // 
            this.firstName.AutoSize = true;
            this.firstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstName.Location = new System.Drawing.Point(163, 143);
            this.firstName.Name = "firstName";
            this.firstName.Size = new System.Drawing.Size(38, 20);
            this.firstName.TabIndex = 9;
            this.firstName.Text = "N/A";
            // 
            // id
            // 
            this.id.AutoSize = true;
            this.id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.id.Location = new System.Drawing.Point(163, 104);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(38, 20);
            this.id.TabIndex = 8;
            this.id.Text = "N/A";
            // 
            // parameter
            // 
            this.parameter.AutoSize = true;
            this.parameter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.parameter.Location = new System.Drawing.Point(163, 70);
            this.parameter.Name = "parameter";
            this.parameter.Size = new System.Drawing.Size(38, 20);
            this.parameter.TabIndex = 7;
            this.parameter.Text = "N/A";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(7, 291);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 20);
            this.label9.TabIndex = 6;
            this.label9.Text = "Role: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 251);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Gender: ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(7, 212);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(122, 20);
            this.label7.TabIndex = 4;
            this.label7.Text = "Date of Birth: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(7, 178);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(105, 20);
            this.label8.TabIndex = 3;
            this.label8.Text = "Last Name: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 143);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 20);
            this.label5.TabIndex = 2;
            this.label5.Text = "First Name: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "ID: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(7, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Parameter: ";
            // 
            // ExitButton
            // 
            this.ExitButton.BackColor = System.Drawing.Color.DarkCyan;
            this.ExitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton.ForeColor = System.Drawing.Color.White;
            this.ExitButton.Location = new System.Drawing.Point(418, 501);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(220, 29);
            this.ExitButton.TabIndex = 10;
            this.ExitButton.Text = "EXIT";
            this.ExitButton.UseVisualStyleBackColor = false;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(804, 536);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.copyright);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.recordsCountLabel);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DataFixer v1.0 - Falcons Team";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label recordsCountLabel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox SeachTermTextBox;
        private System.Windows.Forms.Label copyright;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button SelectCategoryButton;
        private System.Windows.Forms.ComboBox CategoryComboBox;
        private System.Windows.Forms.Button SaveOnFileButton;
        private System.Windows.Forms.Button SelectEmployeeButton;
        private System.Windows.Forms.ListBox employeeList;
        private System.Windows.Forms.Label role;
        private System.Windows.Forms.Label gender;
        private System.Windows.Forms.Label dateOfBirth;
        private System.Windows.Forms.Label lastName;
        private System.Windows.Forms.Label firstName;
        private System.Windows.Forms.Label id;
        private System.Windows.Forms.Label parameter;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label categoryRecordsCount;
        private System.Windows.Forms.Button ResetSearchButton;
    }
}